import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import FreeTrails from './Pages/Freetrails/FreeTrails';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/" element={<FreeTrails />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
